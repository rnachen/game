<filename>   <version>     <url>                                       <build parameters >
libabc.so    1.2.3         http://www.huwei.com/libabc.tar.gz          binary download,  no rebuild
libdef.a     2_4.3         http://libdef.git-hub.comg/master.zip       ./configue --prefix -D && make 
